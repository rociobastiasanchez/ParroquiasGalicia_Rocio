define({
  "_themeLabel": "Chủ đề Hộp",
  "_layout_default": "Bố cục mặc định",
  "_layout_top": "Bố cục trên cùng"
});