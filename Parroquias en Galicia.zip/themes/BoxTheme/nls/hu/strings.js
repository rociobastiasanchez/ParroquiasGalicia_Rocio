define({
  "_themeLabel": "Box téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_top": "Felső elrendezés"
});