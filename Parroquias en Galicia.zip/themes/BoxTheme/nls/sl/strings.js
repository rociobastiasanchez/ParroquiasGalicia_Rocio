define({
  "_themeLabel": "Škatla",
  "_layout_default": "Privzeta postavitev",
  "_layout_top": "Zgornja postavitev"
});