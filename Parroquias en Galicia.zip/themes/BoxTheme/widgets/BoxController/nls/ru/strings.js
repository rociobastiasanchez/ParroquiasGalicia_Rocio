define({
  "_widgetLabel": "Контроллер темы \"коробка\""
});