define({
  "_widgetLabel": "Kutu Denetleyici"
});