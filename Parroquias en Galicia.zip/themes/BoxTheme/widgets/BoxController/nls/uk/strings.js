define({
  "_widgetLabel": "Контролер Box"
});